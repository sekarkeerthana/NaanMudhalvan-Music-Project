# MusicBeats

This is a Music Website made with Python Django Framework.
